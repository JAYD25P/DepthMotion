package com.jaydeep.depthmotion

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/**
 * Stable device tilt input for the parallax renderer.
 *
 * Prefer Android's fused game rotation vector over integrating raw gyro rates.
 * The vector sensor is already fused by the platform and does not accumulate the
 * frame-to-frame rate noise that made the previous gyro integrator visibly twitch.
 */
class TiltSensor(private val context: Context) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val rotationVector: Sensor? =
        manager.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR)
            ?: manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
    private val accel: Sensor? = if (rotationVector == null)
        manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) else null

    val hasMotionSensor: Boolean get() = rotationVector != null || accel != null

    var x = 0f
        private set
    var y = 0f
        private set
    var idleFloat = false

    private var vx = 0f
    private var vy = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var filteredX = 0f
    private var filteredY = 0f
    private var baselineX = 0f
    private var baselineY = 0f
    private var calibrated = false
    private var clock = 0f
    private var running = false
    private var rotation = Surface.ROTATION_0
    private val matrix = FloatArray(9)
    private val remapped = FloatArray(9)
    private val orientation = FloatArray(3)

    fun start() {
        if (running) return
        running = true
        calibrated = false
        targetX = 0f
        targetY = 0f
        refreshRotation()
        val sensor = rotationVector ?: accel ?: return
        manager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_GAME)
    }

    fun stop() {
        if (!running) return
        running = false
        manager.unregisterListener(this)
    }

    fun refreshRotation() {
        rotation = try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
        } catch (_: Throwable) { Surface.ROTATION_0 }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_GAME_ROTATION_VECTOR ||
            event.sensor.type == Sensor.TYPE_ROTATION_VECTOR) {
            SensorManager.getRotationMatrixFromVector(matrix, event.values)
            val axes = when (rotation) {
                Surface.ROTATION_90 -> SensorManager.AXIS_Y to SensorManager.AXIS_MINUS_X
                Surface.ROTATION_180 -> SensorManager.AXIS_MINUS_X to SensorManager.AXIS_MINUS_Y
                Surface.ROTATION_270 -> SensorManager.AXIS_MINUS_Y to SensorManager.AXIS_X
                else -> SensorManager.AXIS_X to SensorManager.AXIS_Y
            }
            SensorManager.remapCoordinateSystem(matrix, axes.first, axes.second, remapped)
            SensorManager.getOrientation(remapped, orientation)

            // Roll and pitch are the useful axes for screen-relative parallax.
            val rawX = deadband(orientation[2] / RANGE)
            val rawY = deadband(-orientation[1] / RANGE)
            updateTarget(rawX, rawY, event.timestamp)
        } else {
            // Fallback for devices without a rotation-vector sensor.
            val norm = kotlin.math.sqrt(
                event.values[0] * event.values[0] +
                    event.values[1] * event.values[1] +
                    event.values[2] * event.values[2]
            )
            if (norm < 1f) return
            val rawX = deadband((event.values[0] / norm) / 0.55f)
            val rawY = deadband((event.values[1] / norm) / 0.55f)
            updateTarget(rawX, rawY, event.timestamp)
        }
    }

    private var lastSensorNanos = 0L
    private fun updateTarget(rawX: Float, rawY: Float, timestamp: Long) {
        val dt = if (lastSensorNanos == 0L) 0.02f
            else ((timestamp - lastSensorNanos) / 1e9f).coerceIn(0.001f, 0.1f)
        lastSensorNanos = timestamp

        if (!calibrated) {
            baselineX = rawX
            baselineY = rawY
            filteredX = 0f
            filteredY = 0f
            calibrated = true
            return
        }

        // Slow adaptive low-pass: suppress micro-tremor while retaining deliberate tilts.
        val alpha = 1f - exp(-dt / FILTER_TAU)
        filteredX += (rawX - filteredX) * alpha
        filteredY += (rawY - filteredY) * alpha
        val dx = filteredX - baselineX
        val dy = filteredY - baselineY
        targetX = deadband(dx).coerceIn(-1f, 1f)
        targetY = deadband(dy).coerceIn(-1f, 1f)

        // Slowly follow the neutral pose only while the phone is nearly still.
        if (abs(targetX) < 0.025f && abs(targetY) < 0.025f) {
            val recenter = 1f - exp(-dt / RECENTER_TAU)
            baselineX += (filteredX - baselineX) * recenter
            baselineY += (filteredY - baselineY) * recenter
        }
    }

    private fun deadband(value: Float): Float {
        val a = abs(value)
        if (a <= DEADZONE) return 0f
        return (if (value < 0f) -1f else 1f) * ((a - DEADZONE) / (1f - DEADZONE))
    }

    /** Advance the critically damped response once per rendered frame. */
    fun step(dtRaw: Float) {
        val dt = dtRaw.coerceIn(0f, 0.05f)
        clock += dt
        val idleX = if (idleFloat && !hasMotionSensor) sin(clock * 0.32f) * 0.035f else 0f
        val idleY = if (idleFloat && !hasMotionSensor) cos(clock * 0.27f) * 0.025f else 0f
        val tx = (targetX + idleX).coerceIn(-1f, 1f)
        val ty = (targetY + idleY).coerceIn(-1f, 1f)

        // Exact critically damped spring integration (stable across refresh rates).
        val omega = SPRING_OMEGA
        val ex = x - tx
        val ey = y - ty
        val cX = vx + omega * ex
        val cY = vy + omega * ey
        val decay = exp(-omega * dt)
        x = tx + (ex + cX * dt) * decay
        y = ty + (ey + cY * dt) * decay
        vx = (vx - omega * cX * dt) * decay
        vy = (vy - omega * cY * dt) * decay
    }

    companion object {
        private const val RANGE = 0.65f
        private const val DEADZONE = 0.035f
        private const val FILTER_TAU = 0.18f
        private const val RECENTER_TAU = 8f
        private const val SPRING_OMEGA = 9f

        fun isSupported(context: Context): Boolean {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            return sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) != null ||
                sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null ||
                sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        }
    }
}
