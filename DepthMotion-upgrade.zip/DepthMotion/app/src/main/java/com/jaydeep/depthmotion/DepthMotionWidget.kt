package com.jaydeep.depthmotion

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.RemoteViews
import kotlin.math.max

class DepthMotionWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { update(context, manager, it) }
    }

    override fun onAppWidgetOptionsChanged(context: Context, manager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, newOptions)
        update(context, manager, appWidgetId)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_REFRESH) refreshAll(context, advance = true)
    }

    companion object {
        const val ACTION_REFRESH = "com.jaydeep.depthmotion.REFRESH"

        /** Advances the photo once (if asked), then redraws every placed widget. */
        fun refreshAll(context: Context, advance: Boolean = false) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, DepthMotionWidget::class.java))
            if (ids.isEmpty()) return
            if (advance) PhotoStore.next(context)
            ids.forEach { update(context, manager, it) }
        }

        fun widgetPixels(context: Context, manager: AppWidgetManager, id: Int): Pair<Int, Int> {
            val o = manager.getAppWidgetOptions(id)
            val wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 160).coerceAtLeast(40)
            val hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 160).coerceAtLeast(40)
            val k = 420f / max(wDp, hDp)
            return Pair((wDp * k).toInt().coerceAtLeast(40), (hDp * k).toInt().coerceAtLeast(40))
        }

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val raw = PhotoStore.current(context)
            val views = RemoteViews(context.packageName, R.layout.widget_depthmotion)
            val target = if (raw == null) SettingsActivity::class.java else DepthViewerActivity::class.java
            val open = PendingIntent.getActivity(
                context, 0, Intent(context, target),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)
            var shown = false
            if (raw != null) {
                val bmp = BitmapLoader.load(context, raw, 720, exactCap = true)
                if (bmp != null) {
                    val image = if (Build.VERSION.SDK_INT >= 31) bmp else neutralFrame(context, manager, id, bmp)
                    views.setImageViewBitmap(R.id.widget_image, image)
                    shown = true
                }
            }
            val motionOn = context.getSharedPreferences("depthmotion", Context.MODE_PRIVATE).getBoolean("motion_enabled", false)
            views.setViewVisibility(R.id.widget_image, if (shown) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_empty, if (shown) View.GONE else View.VISIBLE)
            views.setViewVisibility(R.id.widget_motion, if (shown && motionOn) View.VISIBLE else View.GONE)
            manager.updateAppWidget(id, views)
            PhotoStore.bump(context)
        }

        private fun neutralFrame(context: Context, manager: AppWidgetManager, id: Int, source: Bitmap): Bitmap {
            val (w, h) = widgetPixels(context, manager, id)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(out)
            canvas.drawColor(Color.BLACK)
            val settings = RenderSettings.load(context)
            val renderer = ParallaxRenderer()
            renderer.draw(canvas, Photo(source), w, h, 0f, 0f, settings, 255)
            renderer.drawOverlays(canvas, w, h, 0f, 0f, settings)
            return out
        }
    }
}
