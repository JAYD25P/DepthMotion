package com.jaydeep.depthmotion

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Full-screen viewer with smooth 60 fps depth parallax. Swipe to change photo, tap to hide controls. */
class DepthViewerActivity : AppCompatActivity() {
    private lateinit var parallax: ParallaxView
    private lateinit var hud: LinearLayout
    private lateinit var counter: TextView
    private lateinit var styleChip: TextView
    private lateinit var shineChip: TextView
    private var hudShown = true
    private var changed = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val root = FrameLayout(this)
        parallax = ParallaxView(this)
        root.addView(parallax, FrameLayout.LayoutParams(-1, -1))

        counter = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(dp(14), dp(7), dp(14), dp(7))
            background = pill()
        }
        root.addView(counter, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply {
            setMargins(dp(16), dp(40), 0, 0)
        })

        hud = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(8), dp(12), dp(36))
        }
        styleChip = chip("") { toggleStyle() }
        shineChip = chip("") { toggleShine() }
        hud.addView(styleChip)
        hud.addView(shineChip)
        hud.addView(chip("⚙  Settings") { startActivity(Intent(this, SettingsActivity::class.java)) })
        hud.addView(chip("✕  Close") { finish() })
        root.addView(hud, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(root)

        parallax.onSwipe = { dir -> go(dir) }
        parallax.onTap = { toggleHud() }
        parallax.onDoubleTap = { toggleStyle() }
        parallax.showPhoto(PhotoStore.current(this))
        refreshHud()
    }

    override fun onResume() {
        super.onResume()
        parallax.applySettings()
        refreshHud()
        parallax.resume()
    }

    override fun onPause() {
        parallax.pause()
        super.onPause()
    }

    override fun onStop() {
        if (changed) {
            changed = false
            DepthMotionWidget.refreshAll(this)
        }
        super.onStop()
    }

    override fun onDestroy() {
        parallax.release()
        super.onDestroy()
    }

    private fun go(dir: Int) {
        val uri = PhotoStore.step(this, dir) ?: return
        parallax.showPhoto(uri)
        changed = true
        parallax.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        refreshHud()
    }

    private fun toggleStyle() {
        val p = getSharedPreferences("depthmotion", 0)
        val depth = p.getInt("style", RenderSettings.STYLE_DEPTH) == RenderSettings.STYLE_DEPTH
        p.edit().putInt("style", if (depth) RenderSettings.STYLE_FLAT else RenderSettings.STYLE_DEPTH).apply()
        parallax.applySettings()
        parallax.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        refreshHud()
    }

    private fun toggleShine() {
        val p = getSharedPreferences("depthmotion", 0)
        p.edit().putBoolean("shine", !p.getBoolean("shine", true)).apply()
        parallax.applySettings()
        refreshHud()
    }

    private fun toggleHud() {
        hudShown = !hudShown
        val a = if (hudShown) 1f else 0f
        hud.animate().alpha(a).setDuration(180).start()
        counter.animate().alpha(a).setDuration(180).start()
        hud.visibility = View.VISIBLE
    }

    private fun refreshHud() {
        val (pos, total) = PhotoStore.position(this)
        counter.text = if (total == 0) "No photos yet" else "$pos / $total"
        val p = getSharedPreferences("depthmotion", 0)
        styleChip.text = if (p.getInt("style", RenderSettings.STYLE_DEPTH) == RenderSettings.STYLE_DEPTH) "◈  Depth" else "◇  Flat"
        shineChip.text = if (p.getBoolean("shine", true)) "✦  Shine on" else "✦  Shine off"
    }

    private fun chip(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(14), dp(10), dp(14), dp(10))
        background = pill()
        isClickable = true
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            setMargins(dp(4), 0, dp(4), 0)
        }
        setOnClickListener { action() }
    }

    private fun pill() = GradientDrawable().apply {
        setColor(Color.argb(120, 12, 10, 24))
        cornerRadius = dp(22).toFloat()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
