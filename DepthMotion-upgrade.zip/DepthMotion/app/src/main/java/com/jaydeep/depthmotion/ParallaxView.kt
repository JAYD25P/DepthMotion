package com.jaydeep.depthmotion

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Choreographer
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min

/** Full-screen photo view that renders at display refresh rate with spring-smoothed gyro tilt. */
class ParallaxView(context: Context) : View(context), Choreographer.FrameCallback {
    val settings = RenderSettings.load(context)
    var onSwipe: ((Int) -> Unit)? = null
    var onTap: (() -> Unit)? = null
    var onDoubleTap: (() -> Unit)? = null

    private val tilt = TiltSensor(context)
    private val renderer = ParallaxRenderer()
    private val loader = Executors.newSingleThreadExecutor()
    private var photo: Photo? = null
    private var prev: Photo? = null
    private var fade = 1f
    private var token = 0
    private var running = false
    private var lastNanos = 0L
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(180, 255, 255, 255)
        textAlign = Paint.Align.CENTER
        textSize = 16f * resources.displayMetrics.density
    }

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
        override fun onDoubleTap(e: MotionEvent): Boolean { onDoubleTap?.invoke(); return true }
        override fun onFling(e1: MotionEvent, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
            if (abs(velocityX) > 900f && abs(velocityX) > abs(velocityY) * 1.2f) {
                onSwipe?.invoke(if (velocityX < 0f) 1 else -1)
                return true
            }
            return false
        }
    })

    init {
        tilt.idleFloat = settings.idleFloat
    }

    fun applySettings() {
        val fresh = RenderSettings.load(context)
        settings.sensitivity = fresh.sensitivity
        settings.style = fresh.style
        settings.shine = fresh.shine
        settings.invert = fresh.invert
        settings.idleFloat = fresh.idleFloat
        tilt.idleFloat = fresh.idleFloat
    }

    fun showPhoto(uri: String?) {
        val mine = ++token
        if (uri == null) {
            prev = null; photo = null; invalidate(); return
        }
        loader.execute {
            val bmp = BitmapLoader.load(context, uri, 2048)
            val p = bmp?.let { Photo(it) }
            post {
                if (mine == token && p != null) {
                    prev = photo
                    photo = p
                    fade = if (prev == null) 1f else 0f
                    invalidate()
                }
            }
        }
    }

    fun resume() {
        if (running) return
        running = true
        lastNanos = 0L
        tilt.start()
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun pause() {
        running = false
        tilt.stop()
        Choreographer.getInstance().removeFrameCallback(this)
    }

    fun release() {
        pause()
        loader.shutdownNow()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val dt = if (lastNanos == 0L) 0.016f else (frameTimeNanos - lastNanos) / 1e9f
        lastNanos = frameTimeNanos
        tilt.step(dt)
        if (fade < 1f) {
            fade = min(1f, fade + dt / 0.6f)
            if (fade >= 1f) prev = null
        }
        invalidate()
        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.rgb(17, 16, 27))
        val w = width
        val h = height
        val cur = photo
        if (cur == null) {
            canvas.drawText("Add photos in DepthMotion", w / 2f, h / 2f, hint)
            return
        }
        val old = prev
        if (old != null && fade < 1f) renderer.draw(canvas, old, w, h, tilt.x, tilt.y, settings, 255)
        val eased = fade * fade * (3f - 2f * fade)
        renderer.draw(canvas, cur, w, h, tilt.x, tilt.y, settings, (255 * eased).toInt())
        renderer.drawOverlays(canvas, w, h, tilt.x, tilt.y, settings)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = gestures.onTouchEvent(event)
}
