package com.jaydeep.depthmotion

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.view.Display
import android.view.Surface
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Turns gyroscope (or accelerometer) data into a smooth tilt value in -1..1 on both axes.
 * Gyro rate is integrated with a leak, so drift never builds up and the photo settles back to centre.
 * A critically damped spring removes sensor jitter.
 */
class TiltSensor(private val context: Context) : SensorEventListener {
    private val manager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val gyro: Sensor? = manager.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
    private val accel: Sensor? = if (gyro == null) manager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) else null

    val hasMotionSensor: Boolean get() = gyro != null || accel != null

    var x = 0f
        private set
    var y = 0f
        private set
    var idleFloat = true

    private var vx = 0f
    private var vy = 0f
    private var targetX = 0f
    private var targetY = 0f
    private var angleH = 0f
    private var angleV = 0f
    private var lastTs = 0L
    private var clock = 0f
    private var running = false
    private var rotation = Surface.ROTATION_0

    private var gx = 0f
    private var gy = 0f
    private var gz = 0f
    private var haveG = false
    private var baseLean = 0f
    private var basePitch = 0f
    private var haveBase = false

    fun start() {
        if (running) return
        running = true
        lastTs = 0L
        haveG = false
        haveBase = false
        refreshRotation()
        (gyro ?: accel)?.let { manager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    fun stop() {
        if (!running) return
        running = false
        manager.unregisterListener(this)
    }

    fun refreshRotation() {
        rotation = try {
            val dm = context.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
        } catch (_: Throwable) {
            Surface.ROTATION_0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onSensorChanged(e: SensorEvent) {
        val dt = if (lastTs == 0L) 0f else ((e.timestamp - lastTs) / 1e9f).coerceIn(0f, 0.1f)
        lastTs = e.timestamp
        if (e.sensor.type == Sensor.TYPE_GYROSCOPE) {
            if (dt == 0f) return
            val wx = e.values[0]
            val wy = e.values[1]
            val h: Float
            val v: Float
            when (rotation) {
                Surface.ROTATION_90 -> { h = wx; v = -wy }
                Surface.ROTATION_180 -> { h = -wy; v = -wx }
                Surface.ROTATION_270 -> { h = -wx; v = wy }
                else -> { h = wy; v = wx }
            }
            val dh = if (abs(h) < DEADZONE) 0f else h
            val dv = if (abs(v) < DEADZONE) 0f else v
            val decay = exp(-dt / TAU)
            angleH = (angleH + dh * dt) * decay
            angleV = (angleV + dv * dt) * decay
            targetX = (-angleH / RANGE).coerceIn(-1f, 1f)
            targetY = (-angleV / RANGE).coerceIn(-1f, 1f)
        } else {
            val a = 0.12f
            if (!haveG) {
                gx = e.values[0]; gy = e.values[1]; gz = e.values[2]; haveG = true
            } else {
                gx += (e.values[0] - gx) * a
                gy += (e.values[1] - gy) * a
                gz += (e.values[2] - gz) * a
            }
            val n = sqrt(gx * gx + gy * gy + gz * gz)
            if (n < 1f) return
            val lean = asin((gx / n).coerceIn(-1f, 1f))
            val pitch = atan2(gz / n, gy / n)
            if (!haveBase) {
                baseLean = lean; basePitch = pitch; haveBase = true
            }
            val k = if (dt > 0f) 1f - exp(-dt / 3f) else 0f
            baseLean += (lean - baseLean) * k
            basePitch += wrap(pitch - basePitch) * k
            targetX = ((lean - baseLean) / RANGE).coerceIn(-1f, 1f)
            targetY = (wrap(pitch - basePitch) / RANGE).coerceIn(-1f, 1f)
        }
    }

    /** Advance the spring. Call once per frame with the frame time in seconds. */
    fun step(dtRaw: Float) {
        val dt = dtRaw.coerceIn(0f, 0.25f)
        clock += dt
        val amp = if (idleFloat) (if (hasMotionSensor) 1f else 2.2f) else 0f
        val tx = (targetX + sin(clock * 0.7f) * 0.22f * amp).coerceIn(-1f, 1f)
        val ty = (targetY + cos(clock * 0.53f) * 0.16f * amp).coerceIn(-1f, 1f)
        var left = dt
        while (left > 0f) {
            val h = min(left, 1f / 120f)
            vx += (STIFFNESS * (tx - x) - DAMPING * vx) * h
            vy += (STIFFNESS * (ty - y) - DAMPING * vy) * h
            x += vx * h
            y += vy * h
            left -= h
        }
    }

    private fun wrap(a: Float): Float {
        var r = a
        val twoPi = (2 * PI).toFloat()
        while (r > PI) r -= twoPi
        while (r < -PI) r += twoPi
        return r
    }

    companion object {
        private const val RANGE = 0.35f
        private const val TAU = 2.2f
        private const val DEADZONE = 0.012f
        private const val STIFFNESS = 140f
        private const val DAMPING = 20f

        fun isSupported(context: Context): Boolean {
            val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
            return sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null ||
                sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null
        }
    }
}
