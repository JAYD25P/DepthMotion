package com.jaydeep.depthmotion

import android.app.WallpaperManager
import android.graphics.Canvas
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import java.util.concurrent.Executors
import kotlin.math.min

/** Live wallpaper: the only way to get a true 60 fps gyro render on the home screen. */
class DepthWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DepthEngine()

    inner class DepthEngine : WallpaperService.Engine(), Choreographer.FrameCallback {
        private val tilt = TiltSensor(this@DepthWallpaperService)
        private val renderer = ParallaxRenderer()
        private val loader = Executors.newSingleThreadExecutor()
        private val main = Handler(Looper.getMainLooper())
        private var settings = RenderSettings.load(this@DepthWallpaperService)
        private var photo: Photo? = null
        private var prev: Photo? = null
        private var fade = 1f
        private var visible = false
        private var width = 0
        private var height = 0
        private var lastNanos = 0L
        private var loadedVersion = -1
        private var lastTap = 0L

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            loadCurrent()
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, w: Int, h: Int) {
            super.onSurfaceChanged(holder, format, w, h)
            width = w
            height = h
            tilt.refreshRotation()
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            val choreographer = Choreographer.getInstance()
            if (isVisible) {
                settings = RenderSettings.load(this@DepthWallpaperService)
                tilt.idleFloat = settings.idleFloat
                if (PhotoStore.version(this@DepthWallpaperService) != loadedVersion) loadCurrent()
                lastNanos = 0L
                tilt.start()
                choreographer.removeFrameCallback(this)
                choreographer.postFrameCallback(this)
            } else {
                tilt.stop()
                choreographer.removeFrameCallback(this)
            }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            tilt.stop()
            Choreographer.getInstance().removeFrameCallback(this)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            visible = false
            tilt.stop()
            Choreographer.getInstance().removeFrameCallback(this)
            loader.shutdownNow()
            super.onDestroy()
        }

        override fun onCommand(action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) {
                val now = SystemClock.uptimeMillis()
                if (now - lastTap < 450L) {
                    PhotoStore.step(this@DepthWallpaperService, 1)
                    loadCurrent()
                    lastTap = 0L
                } else lastTap = now
            }
            return super.onCommand(action, x, y, z, extras, resultRequested)
        }

        private fun loadCurrent() {
            val version = PhotoStore.version(this@DepthWallpaperService)
            val uri = PhotoStore.current(this@DepthWallpaperService)
            loadedVersion = version
            if (uri == null) return
            loader.execute {
                val bmp = BitmapLoader.load(this@DepthWallpaperService, uri, 2048)
                val p = bmp?.let { Photo(it) }
                main.post {
                    if (p != null) {
                        prev = photo
                        photo = p
                        fade = if (prev == null) 1f else 0f
                    }
                }
            }
        }

        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            val dt = if (lastNanos == 0L) 0.016f else (frameTimeNanos - lastNanos) / 1e9f
            lastNanos = frameTimeNanos
            tilt.step(dt)
            if (fade < 1f) {
                fade = min(1f, fade + dt / 0.6f)
                if (fade >= 1f) prev = null
            }
            drawFrame()
            Choreographer.getInstance().postFrameCallback(this)
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockHardwareCanvas()
                if (canvas == null) return
                val w = canvas.width
                val h = canvas.height
                canvas.drawColor(Color.rgb(17, 16, 27))
                val cur = photo ?: return
                val old = prev
                if (old != null && fade < 1f) renderer.draw(canvas, old, w, h, tilt.x, tilt.y, settings, 255)
                val eased = fade * fade * (3f - 2f * fade)
                renderer.draw(canvas, cur, w, h, tilt.x, tilt.y, settings, (255 * eased).toInt())
                renderer.drawOverlays(canvas, w, h, tilt.x, tilt.y, settings)
            } catch (_: Throwable) {
            } finally {
                if (canvas != null) {
                    try { holder.unlockCanvasAndPost(canvas) } catch (_: Throwable) {}
                }
            }
        }
    }
}
