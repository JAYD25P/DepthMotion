package com.jaydeep.depthmotion

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class RenderSettings(
    var sensitivity: Float = 1f,
    var style: Int = STYLE_DEPTH,
    var shine: Boolean = true,
    var invert: Boolean = false,
    var idleFloat: Boolean = true
) {
    companion object {
        const val STYLE_FLAT = 0
        const val STYLE_DEPTH = 1
        fun load(context: Context): RenderSettings {
            val p = context.getSharedPreferences("depthmotion", Context.MODE_PRIVATE)
            return RenderSettings(
                sensitivity = p.getInt("sensitivity", 55).coerceIn(10, 100) / 55f,
                style = p.getInt("style", STYLE_DEPTH),
                shine = p.getBoolean("shine", true),
                invert = p.getBoolean("invert", false),
                idleFloat = p.getBoolean("float", true)
            )
        }
    }
}

/** A decoded photo plus an estimated depth grid used for the 3D warp. */
class Photo(val bitmap: Bitmap) {
    val depth: FloatArray = DepthField.build(bitmap)
}

/** Estimates depth: centre of the frame reads as near, brighter areas read slightly nearer. */
object DepthField {
    const val COLS = 24
    const val ROWS = 32

    fun build(src: Bitmap): FloatArray {
        val w = COLS + 1
        val h = ROWS + 1
        val small = Bitmap.createScaledBitmap(src, w, h, true)
        val px = IntArray(w * h)
        small.getPixels(px, 0, w, 0, 0, w, h)
        if (small !== src) small.recycle()
        var lum = FloatArray(w * h) { i ->
            val c = px[i]
            (0.299f * Color.red(c) + 0.587f * Color.green(c) + 0.114f * Color.blue(c)) / 255f
        }
        repeat(2) { lum = blur(lum, w, h) }
        var mn = Float.MAX_VALUE
        var mx = -Float.MAX_VALUE
        for (v in lum) { mn = min(mn, v); mx = max(mx, v) }
        val range = max(mx - mn, 0.05f)
        val d = FloatArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val l = (lum[y * w + x] - mn) / range
            val cx = x / (w - 1f) * 2f - 1f
            val cy = y / (h - 1f) * 2f - 1f
            val center = 1f - min(1f, sqrt(cx * cx * 0.8f + cy * cy * 0.6f))
            d[y * w + x] = 0.3f * l + 0.7f * center
        }
        var dmn = Float.MAX_VALUE
        var dmx = -Float.MAX_VALUE
        for (v in d) { dmn = min(dmn, v); dmx = max(dmx, v) }
        val dr = max(dmx - dmn, 1e-3f)
        for (i in d.indices) d[i] = (d[i] - dmn) / dr * 2f - 1f
        return d
    }

    private fun blur(a: FloatArray, w: Int, h: Int): FloatArray {
        val out = FloatArray(a.size)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0f
            var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) { s += a[yy * w + xx]; n++ }
            }
            out[y * w + x] = s / n
        }
        return out
    }
}

class ParallaxRenderer {
    private val cols = DepthField.COLS
    private val rows = DepthField.ROWS
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val verts = FloatArray((cols + 1) * (rows + 1) * 2)
    private val matrix = Matrix()
    private val shineMatrix = Matrix()
    private val shinePaint = Paint()
    private val vignettePaint = Paint()
    private var shineShader: RadialGradient? = null
    private var lastW = 0
    private var lastH = 0

    fun draw(canvas: Canvas, photo: Photo, w: Int, h: Int, tx: Float, ty: Float, s: RenderSettings, alpha: Int) {
        val bmp = photo.bitmap
        if (bmp.isRecycled || w <= 0 || h <= 0) return
        val dir = if (s.invert) -1f else 1f
        val nx = tx * dir
        val ny = ty * dir
        val f = 0.035f * s.sensitivity
        val maxX = f * w
        val maxY = f * h
        val zoom = 1f + 2f * f + 0.012f
        val scale = max(w / bmp.width.toFloat(), h / bmp.height.toFloat()) * zoom
        val dw = bmp.width * scale
        val dh = bmp.height * scale
        val left = (w - dw) / 2f
        val top = (h - dh) / 2f
        paint.alpha = alpha.coerceIn(0, 255)
        if (s.style == RenderSettings.STYLE_DEPTH) {
            var k = 0
            for (j in 0..rows) for (i in 0..cols) {
                val d = photo.depth[j * (cols + 1) + i]
                val factor = 0.55f + 0.45f * d
                verts[k++] = left + dw * i / cols + nx * maxX * factor
                verts[k++] = top + dh * j / rows + ny * maxY * factor
            }
            canvas.drawBitmapMesh(bmp, cols, rows, verts, 0, null, 0, paint)
        } else {
            matrix.reset()
            matrix.setScale(scale, scale)
            matrix.postTranslate(left + nx * maxX, top + ny * maxY)
            canvas.drawBitmap(bmp, matrix, paint)
        }
    }

    fun drawOverlays(canvas: Canvas, w: Int, h: Int, tx: Float, ty: Float, s: RenderSettings) {
        ensureOverlays(w, h)
        canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vignettePaint)
        if (s.shine) {
            val dir = if (s.invert) -1f else 1f
            shineMatrix.setTranslate(w * (0.5f - 0.55f * tx * dir), h * (0.32f - 0.45f * ty * dir))
            shineShader?.setLocalMatrix(shineMatrix)
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), shinePaint)
        }
    }

    private fun ensureOverlays(w: Int, h: Int) {
        if (w == lastW && h == lastH) return
        lastW = w
        lastH = h
        val r = max(w, h) * 0.75f
        val shine = RadialGradient(
            0f, 0f, r,
            intArrayOf(Color.argb(70, 255, 255, 255), Color.argb(18, 255, 255, 255), Color.argb(0, 255, 255, 255)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        shineShader = shine
        shinePaint.shader = shine
        vignettePaint.shader = RadialGradient(
            w / 2f, h / 2f, r,
            intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(140, 0, 0, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
        )
    }
}
