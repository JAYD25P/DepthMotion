package com.jaydeep.depthmotion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.util.TypedValue
import android.widget.RemoteViews
import androidx.annotation.RequiresApi
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Drives the home-screen widget. On Android 12+ it sends tiny margin updates (a few numbers)
 * instead of a new bitmap each frame, which is far lighter than before. Older versions get small
 * rendered frames. Sensors pause while the screen is off.
 */
class GyroMotionService : Service() {
    private lateinit var tilt: TiltSensor
    private lateinit var power: PowerManager
    private val handler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val renderer = ParallaxRenderer()
    private val frames = HashMap<Int, Bitmap>()
    private var settings = RenderSettings()
    private var photo: Photo? = null
    private var loadedVersion = -1
    private var seenVersion = -1
    private var loading = false
    private var sensing = false
    private var lastNs = 0L
    private var lastShiftX = Float.NaN
    private var lastShiftY = Float.NaN
    private var useBitmapPath = Build.VERSION.SDK_INT < 31

    private val ticker = Runnable { tick() }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val stop = PendingIntent.getService(
            this, 9, Intent(this, GyroMotionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("DepthMotion is active")
            .setContentText("Gyroscope parallax is moving your home-screen photo")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "Stop motion", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(NOTIFICATION_ID, notification)

        power = getSystemService(Context.POWER_SERVICE) as PowerManager
        tilt = TiltSensor(this)
        settings = RenderSettings.load(this)
        tilt.idleFloat = settings.idleFloat
        handler.post(ticker)
    }

    private fun tick() {
        var next = FRAME_MS
        if (!power.isInteractive) {
            if (sensing) { tilt.stop(); sensing = false }
            next = 1000L
        } else {
            if (!sensing) {
                settings = RenderSettings.load(this)
                tilt.idleFloat = settings.idleFloat
                tilt.start()
                sensing = true
                lastNs = 0L
            }
            val now = System.nanoTime()
            val dt = if (lastNs == 0L) 0.05f else (now - lastNs) / 1e9f
            lastNs = now
            tilt.step(dt)
            val v = PhotoStore.version(this)
            if (v != seenVersion) { seenVersion = v; lastShiftX = Float.NaN }
            pushFrame()
            if (useBitmapPath) next = BITMAP_FRAME_MS
        }
        handler.postDelayed(ticker, next)
    }

    private fun pushFrame() {
        val manager = AppWidgetManager.getInstance(this)
        val ids = manager.getAppWidgetIds(ComponentName(this, DepthMotionWidget::class.java))
        if (ids.isEmpty()) return
        if (!useBitmapPath && Build.VERSION.SDK_INT >= 31) {
            val dir = if (settings.invert) -1f else 1f
            val sx = (tilt.x * dir * SHIFT_DP * settings.sensitivity).coerceIn(-MARGIN_DP, MARGIN_DP)
            val sy = (tilt.y * dir * SHIFT_DP * settings.sensitivity).coerceIn(-MARGIN_DP, MARGIN_DP)
            if (!lastShiftX.isNaN() && abs(sx - lastShiftX) < 0.35f && abs(sy - lastShiftY) < 0.35f) return
            lastShiftX = sx
            lastShiftY = sy
            try {
                ids.forEach { pushShift(manager, it, sx, sy) }
            } catch (_: Throwable) {
                useBitmapPath = true
            }
        } else {
            renderBitmaps(manager, ids)
        }
    }

    @RequiresApi(31)
    private fun pushShift(manager: AppWidgetManager, id: Int, sx: Float, sy: Float) {
        val v = RemoteViews(packageName, R.layout.widget_depthmotion)
        val unit = TypedValue.COMPLEX_UNIT_DIP
        v.setViewLayoutMargin(R.id.widget_image, RemoteViews.MARGIN_LEFT, -MARGIN_DP + sx, unit)
        v.setViewLayoutMargin(R.id.widget_image, RemoteViews.MARGIN_RIGHT, -MARGIN_DP - sx, unit)
        v.setViewLayoutMargin(R.id.widget_image, RemoteViews.MARGIN_TOP, -MARGIN_DP + sy, unit)
        v.setViewLayoutMargin(R.id.widget_image, RemoteViews.MARGIN_BOTTOM, -MARGIN_DP - sy, unit)
        manager.partiallyUpdateAppWidget(id, v)
    }

    private fun renderBitmaps(manager: AppWidgetManager, ids: IntArray) {
        ensurePhoto()
        val p = photo ?: return
        ids.forEach { id ->
            val (w, h) = DepthMotionWidget.widgetPixels(this, manager, id)
            val bmp = frames[id]?.takeIf { it.width == w && it.height == h }
                ?: Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { frames[id] = it }
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.BLACK)
            renderer.draw(canvas, p, w, h, tilt.x, tilt.y, settings, 255)
            renderer.drawOverlays(canvas, w, h, tilt.x, tilt.y, settings)
            val v = RemoteViews(packageName, R.layout.widget_depthmotion)
            v.setImageViewBitmap(R.id.widget_image, bmp)
            manager.partiallyUpdateAppWidget(id, v)
        }
    }

    private fun ensurePhoto() {
        val version = PhotoStore.version(this)
        if (version == loadedVersion || loading) return
        loading = true
        worker.execute {
            val raw = PhotoStore.current(this)
            val bmp = raw?.let { BitmapLoader.load(this, it, 720, exactCap = true) }
            val ph = bmp?.let { Photo(it) }
            handler.post {
                loadedVersion = version
                photo = ph
                loading = false
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("depthmotion", 0).edit().putBoolean("motion_enabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        tilt.stop()
        worker.shutdownNow()
        frames.clear()
        getSharedPreferences("depthmotion", 0).edit().putBoolean("motion_enabled", false).apply()
        DepthMotionWidget.refreshAll(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(NotificationChannel(CHANNEL, "DepthMotion motion", NotificationManager.IMPORTANCE_LOW))
    }

    companion object {
        private const val CHANNEL = "depthmotion_motion"
        private const val NOTIFICATION_ID = 41
        private const val FRAME_MS = 50L
        private const val BITMAP_FRAME_MS = 150L
        private const val MARGIN_DP = 12f
        private const val SHIFT_DP = 6.5f
        const val ACTION_STOP = "com.jaydeep.depthmotion.STOP_MOTION"

        fun start(context: Context) {
            context.getSharedPreferences("depthmotion", 0).edit().putBoolean("motion_enabled", true).apply()
            context.startForegroundService(Intent(context, GyroMotionService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, GyroMotionService::class.java))
            context.getSharedPreferences("depthmotion", 0).edit().putBoolean("motion_enabled", false).apply()
        }
    }
}
